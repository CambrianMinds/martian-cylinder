# Independent Geometric Investigation: Curiosity Sol 3556 (`3556MR1025170721700585C00`)

**Target Observation**: `3556MR1025170721700585C00` (MSL Mastcam-100 Right, Sol 3556, `2022-08-07T20:58:23.349` UTC)  
**Primary Data Products**: `3556MR1025170721700585C00_DRXX.IMG/.LBL` (16-bit linear radiance, raw `CAHVOR` geometry) and `_DRLX.IMG/.LBL` (16-bit linear radiance, `CAHV` linearized geometry)  
**Output Directory**: `independent-reconstruction/`

---

## Executive Summary

1. **Strongest Result (Projective & Geometric Characterization)**:  
   The sunlit body of the object is bounded by two straight, non-parallel longitudinal edges—an exceptionally straight upper-right (dorsal) edge at image angle $\theta_{\text{dorsal}} = 29.88^\circ \pm 0.27^\circ$ (orthogonal $\text{RMS} = 0.262\text{ px} \approx 77\ \mu\text{m}$ at $D = 3.957\text{ m}$ over a $36.8\text{ px}$ span) and a lower-left (ventral) edge at $\theta_{\text{ventral}} = 65.23^\circ \pm 0.56^\circ$ ($\text{RMS} = 0.589\text{ px}$)—that **converge toward an upper-left apex at an opening angle of $2\alpha = 35.35^\circ \pm 0.62^\circ$** ($35.25^\circ$ in linearized `DRLX`). Using the exact Mastcam-100 `CAHVOR` camera model ($f_{\text{local}} = 13,458.3\text{ px/rad}$, $\text{IFOV} = 74.30\ \mu\text{rad/px}$), we prove analytically and numerically that two physically parallel 3D edges separated by $\sim 35.5\text{ px}$ ($\sim 10.5\text{ mm}$) at $D \approx 4\text{ m}$ converge via perspective foreshortening by only **$0.07^\circ\text{ to }0.35^\circ$** across any plausible tilt angle $\gamma \in [20^\circ, 75^\circ]$. Consequently, **an uncovered, free-standing right circular cylinder is geometrically ruled out at $>50\sigma$**. Meanwhile, the bright-to-dark terminal arch (`Zone 3`, spanning $140^\circ\text{–}160^\circ$ of polar angle) is smoothly curved ($\text{RMS} = 0.162\text{ px}$ for a 4-DOF ellipse aligned with the dorsal edge vs. $1.122\text{ px}$ for a 2-facet angular fracture, $\Delta\text{AIC}_c = +1887.8$), and transverse radiometric profiles across the sunlit surface exhibit statistically significant convex limb shading ($z = 7.38\sigma$ against a flat planar facet). Finally, exact 3D-to-2D solar ray casting ($\theta_{\text{shadow}} = +63.43^\circ$ from `SOLAR_AZIMUTH = 186.82°`, `SOLAR_ELEVATION = 69.82°`) proves that the lower-right half of the dark patch (`Zone 4`) is the **cast shadow of the overhanging upper-left arch projected onto the underlying soil**, explaining why full $360^\circ$ contour ellipse fits fail ($\text{RMS} = 1.760\text{ px}$, $\chi^2_\nu = 77.85$).

2. **Strongest Competing Interpretations**:  
   Because monocular boundary and shading measurements support a smoothly curved convex body with converging visible margins ($2\alpha = 35.35^\circ$) and an overhanging arched termination, three physical 3D geometries remain viable:
   - **Interpretation A (Convex Tapered Spall / Fluted Ventifact Clast — Model H3b)**: A wind-abraded or curvi-planarly spalled sedimentary rock fragment (in a scene explicitly acquired to document laminated Bolivar cliff-face bedding styles) possessing a convex dorsal ridge, a tapered wedge-like planform ($35.35^\circ$), and an undercut, overhanging lower-right fracture lip that casts a $+63.43^\circ$ shadow across the regolith.
   - **Interpretation B (Conical / Frustum-Shaped Body — Model H2)**: A genuinely tapered conical or frustum-like solid (or hollow conical shell) whose two straight margins are true 3D silhouette limbs ($\sin\alpha = \tan\beta / \sin\gamma$, giving 3D half-cone angle $\beta \approx 9.5^\circ\text{–}14.5^\circ$ for $\gamma \in [33^\circ, 55^\circ]$).
   - **Interpretation C (Obliquely Buried Right Circular Cylinder — Model H1b)**: A right circular cylinder of diameter $2a \approx 39.5\text{ px}$ ($11.6\text{ mm}$ at $D=3.957\text{ m}$) whose dorsal edge ($\theta_{\text{dorsal}} = 29.88^\circ$) is the true exposed upper cylinder limb—remarkably matching the minor-axis orientation of the unconstrained proximal arch ellipse ($\phi_{\text{minor}} = 32.54^\circ \pm 6.37^\circ$, $\Delta\theta = 2.67^\circ$)—while its lower-left flank is progressively occluded by an oblique foreground regolith ridge at $\theta_{\text{ventral}} = 65.23^\circ$.

3. **Single Most Important Unresolved Question**:  
   **Is the lower-left (ventral) boundary ($\theta_{\text{ventral}} = 65.23^\circ$) a true 3D physical edge/limb of a tapered object, or an occlusion/burial contact line where foreground Martian soil overlaps a non-tapering cylinder?** In a single monocular image at $0.294\text{ mm/px}$ scale without stereo disparity or multi-azimuth viewing, an oblique regolith occlusion contact and a physical conical/wedge edge project to nearly indistinguishable 2D intensity transitions, leaving the object's unseen subsurface continuation and true 3D axial taper fundamentally underdetermined.

---

## 1. Observations: Provenance, Radiometry, and Directly Visible Features

### 1.1 Image Provenance and Instrumental Characteristics
Inspection of the primary PDS3 labels (`3556MR1025170721700585C00_DRXX.LBL` and `_DRLX.LBL`) establishes the following exact observational parameters:
- **Acquisition**: Mars Science Laboratory (Curiosity) Sol 3556, `2022-08-07T20:58:23.349` UTC, Local True Solar Time `12:10:25` (`Sol-03556M12:34:53.510` LMST), $L_s = 281.015^\circ$, Site 96, Drive 2376, Pose 16.
- **Instrument & Optics**: Mastcam-100 Right (`MAST_RIGHT`, serial `3004`, focal length $\approx 100\text{ mm}$), clear filter `MASTCAM_R0_CLEAR` ($575\text{ nm}$ center wavelength), exposure duration $14.2\text{ ms}$, focus motor position count `2705` corresponding to `MSL:BEST_FOCUS_DISTANCE = 3.957 m` (`MINIMUM_FOCUS_DISTANCE = 3.6 m`, `MAXIMUM_FOCUS_DISTANCE = 4.4 m`).
- **Detector Subframing**: Subframed from the full $1648 \times 1200$ CCD starting at 1-based detector coordinates $(\text{FIRST\_LINE\_SAMPLE}, \text{FIRST\_LINE}) = (161, 17)$, yielding dimensions of $1328 \times 1184\text{ px}$ for raw `CAHVOR` products (`DRXX`, `DRCX`) and $1323 \times 1180\text{ px}$ for `CAHV` linearized products (`DRLX`, `DRCL`).
- **Lack of Lossy JPEG Block Artifacts**: Crucially, the PDS label specifies `INST_CMPRS_MODE = 1` (`INST_CMPRS_NAME = "PREDICTIVE LOSSLESS BAYER HUFFMAN ENCODING"`, `SAMPLE_BIT_MODE_ID = MMM_LUT0`). Unlike lossy JPEG Mastcam downlinks, **this image was downlinked lossless in spatial frequency**, eliminating $8\times 8$ DCT blocking as an artifact source. The real pixel-level instrumental effects are:
  1. **Bayer CFA Demosaicing (`C00`)**: On-ground interpolation of the RGBG Bayer filter array introduces $3\times 3$ to $5\times 5$ spatial covariance and minor chromatic differences across sharp edges (visualized in `figures/diag02_radiometric_comparison.png`).
  2. **Optical PSF Blur**: Measured directly across the dorsal edge in `DRXX` at $\sigma_{\text{PSF}} = 0.508\text{ px}$ ($\text{FWHM} = 1.20\text{ px}$) and across the overhanging rim arch at $\sigma_{\text{PSF}} = 0.978\text{ px}$.
  3. **LUT Companding Quantization**: Hardware 12-to-8-bit `MMM_LUT0` companding yields $1711$ unique DN values in Band 0 of `DRXX` across $[0, 1847]$.

### 1.2 Target Localization and Anatomical Zones
In 0-based `DRXX` pixel coordinates $(x, y) = (\text{sample}, \text{line})$ (where `DRLX` is offset by $(\Delta x, \Delta y) = (-3, -3)\text{ px}$, cross-correlation $r = 0.9978$), the target object occupies `x ∈ [1031, 1092]`, `y ∈ [946, 1004]` (1-based full detector coordinates `sample ∈ [1192, 1253]`, `line ∈ [963, 1021]`). We partition the feature into six observable zones (`figures/diag03_subpixel_edges.png`):

| Zone | Feature Description | `DRXX` 0-Based Pixel Bounds | Observability & Physical Ambiguity Status |
| :--- | :--- | :--- | :--- |
| **Zone 1** | **Dorsal (Upper-Right) Longitudinal Edge** | $x \in [1036.0, 1068.5]$, $y \in [947.2, 963.6]$ | **Directly observable, unambiguous**: High-contrast, sharp, unobstructed linear boundary separating the sunlit upper surface from darker background regolith. |
| **Zone 2** | **Ventral (Lower-Left) Longitudinal Edge** | $x \in [1033.2, 1051.2]$, $y \in [952.5, 989.5]$ | **Directly observable but physically ambiguous**: Linear boundary separating the sunlit object from underlying soil; bordered near $y \in [978.5, 986.5]$ by an adjacent small clast/pebble at $(1036, 983)$. Ambiguous whether it is a free 3D edge or a soil burial contact. |
| **Zone 3** | **Proximal Sunlit-to-Dark Rim Arch** | $x \in [1052.1, 1081.0]$, $y \in [967.1, 994.1]$ ($\theta \in [+150^\circ, -50^\circ]$) | **Directly observable, unambiguous**: High-contrast ($\text{SNR} = 10.9$), smoothly curved arch where the sunlit body terminates against deep shadow. |
| **Zone 4** | **Distal Dark-to-Soil Shadow Boundary** | $x \in [1054.0, 1092.0]$, $y \in [969.0, 1004.0]$ ($\theta \in [-45^\circ, +145^\circ]$) | **Directly observable as a shadow boundary, NOT an object rim**: Lower-contrast ($2.2\times$ weaker step) irregular boundary with a pronounced lobe at $(1091, 990)$ where cast shadow meets sunlit pebbles/regolith. |
| **Zone 5** | **Upper-Left Apex / Tip** | $x \in [1031.0, 1036.0]$, $y \in [945.5, 952.0]$ | **Blurred / partially buried**: Over spans $\lesssim 3\text{ px}$ near $(1032.8, 945.9)$, the converging dorsal and ventral edges merge into the surrounding soil at the scale of the PSF ($\sim 1.5\text{ px}$). |
| **Zone 6** | **Sunlit Body Interior Surface** | $x \in [1035.0, 1070.0]$, $y \in [950.0, 988.0]$ | **Directly measurable radiometry**: Smoothly varying spectral radiance ($I_{\text{mean}} = 0.0985\text{ W m}^{-2}\text{ sr}^{-1}\text{ nm}^{-1}$), free of internal steps, seams, bolts, or grooves at $0.29\text{ mm/px}$ resolution. |

---

## 2. Measurements: Camera Geometry, Subpixel Coordinates, and Dimensional Ratios

### 2.1 Camera Viewing and Illumination Geometry (`step2_camera_geometry.json`)
From the PDS `CAHVOR` (`DRXX`) and `CAHV` (`DRLX`) vectors and the rover-to-site quaternion $q = (0.3101999, -0.1235113, -0.0378476, 0.9418538)$:
- **Intrinsic Scale**: In `DRXX`, $(h_c, v_c) = (699.44, 518.29)\text{ px}$, $(h_s, v_s) = (13376.27, 13370.53)\text{ px/rad}$ ($\text{IFOV} = 74.76\ \mu\text{rad/px}$ paraxial; $74.304\ \mu\text{rad/px}$ local at target). In linearized `DRLX`, $(h_s, v_s) = (13593.66, 13593.66)\text{ px/rad}$ ($\text{IFOV} = 73.564\ \mu\text{rad/px}$, aspect ratio $1.0000003$).
- **Viewing Direction at Target $(1061, 980)$**:
  - `SITE_FRAME` Azimuth: $229.0465^\circ$ clockwise from North; Elevation: $-23.9511^\circ$ (grazing angle $23.9511^\circ$ relative to horizontal).
  - Off-axis angle from optical axis $\mathbf{A}$: $2.5054^\circ$ ($2.3907^\circ$ from distortion axis $\mathbf{O}$).
  - Local `CAHVOR` Jacobian singular values: $\sigma_1 = 13498.24\text{ px/rad}$, $\sigma_2 = 13418.43\text{ px/rad}$, giving a local optical distortion anisotropy of **$0.5948\%$** ($\sigma_1/\sigma_2 = 1.005948$). Thus, radial lens distortion is negligible ($<0.6\%$).
- **Solar Illumination Geometry**:
  - `SOLAR_AZIMUTH = 186.8169°`, `SOLAR_ELEVATION = 69.8224°` in `SITE_FRAME` (phase angle $81.510^\circ$ at target).
  - Projected into the 2D camera image plane ($+x$ right, $+y$ down), sunlight arrives from image angle **$\theta_{\text{sun}} = -116.571^\circ$** (upper-left), so **shadows are cast in the 2D image along $\theta_{\text{shadow}} = +63.429^\circ$** (downward and right, with slope $\Delta y / \Delta x = \tan 63.429^\circ = 2.000$).

### 2.2 Longitudinal Edge Measurements (`step3_features.json`)

| Feature / Metric | `DRXX` Erf Subpixel Fit | `DRXX` Parabolic Gradient | `DRLX` (`CAHV` Linearized) | Units |
| :--- | :--- | :--- | :--- | :--- |
| **Dorsal Edge Angle ($\theta_{\text{dorsal}}$)** | $29.878 \pm 0.269$ | $30.052 \pm 0.291$ | $29.965 \pm 0.265$ | deg |
| **Dorsal Edge Span ($L_{\text{fit}}$)** | $36.78$ | $36.75$ | $36.76$ | px |
| **Dorsal Orthogonal RMS Residual** | **$0.2620$** | $0.2785$ | **$0.2593$** | px |
| **Dorsal Max Orthogonal Residual** | $0.6452$ | $0.6810$ | $0.6124$ | px |
| **Dorsal Quadratic Curvature ($c_2$)** | $(-1.05 \pm 0.45)\times 10^{-3}$ | $(-1.12 \pm 0.48)\times 10^{-3}$ | $(-1.01 \pm 0.44)\times 10^{-3}$ | $\text{px}^{-1}$ |
| **Dorsal Curvature Significance ($|c_2|/\sigma_{c_2}$)** | $2.33\sigma$ ($\delta_{\text{sag}} = 0.357\text{ px}$) | $2.31\sigma$ | $2.29\sigma$ | — |
| **Ventral Edge Angle — Full ($\theta_{\text{ventral}}$)** | $65.226 \pm 0.563$ | $65.284 \pm 0.590$ | $65.214 \pm 0.612$ | deg |
| **Ventral Edge Angle — Clean (Pebble Excluded)** | $65.968 \pm 0.540$ | $65.892 \pm 0.575$ | $65.885 \pm 0.580$ | deg |
| **Ventral Orthogonal RMS Residual (Full / Clean)** | $0.5891$ / $0.5621$ | $0.6140$ / $0.5812$ | $0.6582$ / $0.6190$ | px |
| **Longitudinal Convergence Opening Angle ($2\alpha$)** | **$35.348 \pm 0.624$** (Clean: $36.090$) | $35.232 \pm 0.658$ | **$35.249 \pm 0.667$** | deg |
| **Longitudinal Bisector Angle ($\theta_{\text{bis}}$)** | $47.552 \pm 0.312$ (Clean: $47.923$) | $47.668 \pm 0.330$ | $47.590 \pm 0.334$ | deg |
| **Extrapolated Apex Intersection $(x_{\text{apex}}, y_{\text{apex}})$** | $(1032.76 \pm 0.45,\, 945.93 \pm 0.42)$ | $(1032.89,\, 946.04)$ | $(1029.81,\, 942.95)$ | px |

### 2.3 Apparent Dimensional Ratios and Metric Scale Bounds (`measurements.json`)
- **Dimensionless Pixel Ratios (Distance-Invariant)**:
  - Proximal Arch Rim Chord Width (from ventral corner $(1052.10, 994.08)$ to dorsal termination $(1076.62, 968.32)$): $W_{\text{chord}} = 35.54 \pm 0.35\text{ px}$ ($2.641\text{ mrad}$).
  - Fitted Proximal Arch Ellipse Major Diameter ($2a$): $36.62 \pm 1.50\text{ px}$ on `S1` ($140^\circ$ strict rim); $39.47 \pm 1.51\text{ px}$ on `S2` ($160^\circ$ full proximal rim).
  - Exposed Dorsal Limb Length (from apex $(1032.76, 945.93)$ to dorsal arch corner $(1076.62, 968.32)$): $L_{\text{dorsal}} = 48.03 \pm 0.55\text{ px}$ ($3.569\text{ mrad}$).
  - Exposed Ventral Limb Length (from apex to ventral arch corner): $L_{\text{ventral}} = 51.80 \pm 0.65\text{ px}$ ($3.849\text{ mrad}$).
  - Sunlit Axial Length along Bisector (from apex to proximal arch vertex $(1060.2, 971.2)$): $L_{\text{axial}} = 37.30 \pm 0.50\text{ px}$ ($2.772\text{ mrad}$).
  - **Apparent Length-to-Width Ratios**:
    $$\frac{L_{\text{dorsal}}}{W_{\text{chord}}} = 1.351 \pm 0.020, \quad \frac{L_{\text{axial}}}{W_{\text{chord}}} = 1.050 \pm 0.018$$
- **Metric Dimensions Across Plausible Monocular Distance Scenarios**:

| Distance Scenario | Slant Range $D$ (m) | Pixel Scale (mm/px) | Rim Chord Width $W_{\text{chord}}$ (mm) | Ellipse Major Diam $2a$ (`S1` / `S2`) (mm) | Sunlit Axial Length $L_{\text{axial}}$ (mm) | Dorsal Limb Length $L_{\text{dorsal}}$ (mm) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `ROVER_NAV_FRAME` $Z_{\text{nav}}=0$ Plane | $3.5539$ | $0.26407$ | $9.39$ | $9.67$ / $10.42$ | $9.85$ | $12.68$ |
| Minimum Autofocus Bound | $3.6000$ | $0.26749$ | $9.51$ | $9.80$ / $10.56$ | $9.98$ | $12.85$ |
| **Best Focus Distance (`MSL:BEST_FOCUS_DISTANCE`)** | **$3.9570$** | **$0.29402$** | **$10.45$** | **$10.77$ / $11.61$** | **$10.97$** | **$14.12$** |
| Maximum Autofocus Bound | $4.4000$ | $0.32694$ | $11.62$ | $11.97$ / $12.90$ | $12.19$ | $15.70$ |
| `SITE_FRAME` Horizontal Plane at Rover Origin | $5.1764$ | $0.38462$ | $13.67$ | $14.08$ / $15.18$ | $14.35$ | $18.47$ |

---

## 3. Models: Mathematical Formulations Tested and Quantitative Performance

### 3.1 Terminal Boundary / End-Face Model Comparison (`step4_endface_models.json`)
We evaluated six geometric curve models via exact Euclidean Orthogonal Distance Regression across four boundary subsets (`figures/diag04_endface_models.png`):
- **`S1_Strict_Proximal_Arch_140deg` ($N=29$)**: Strictly the high-contrast ($\Delta I > 0.07\text{ W m}^{-2}\text{ sr}^{-1}\text{ nm}^{-1}$) sunlit-to-shadow termination ($\theta \in [+160^\circ, -60^\circ]$).
- **`S2_Full_Proximal_Rim_160deg` ($N=33$)**: Complete overhanging rim including dorsal and ventral corners ($\theta \in [+150^\circ, -50^\circ]$).
- **`S3_Lobe_Excluded_250deg` ($N=50$)**: Including bottom shadow-to-soil contact while excluding the right-hand shadow lobe ($\theta \notin [-30^\circ, +75^\circ]$).
- **`S4_Full_360deg_Dark_Patch` ($N=72$)**: Full $360^\circ$ dark region (conflating the physical rim with the cast shadow on the soil).

| Subset & Model | $k$ | DOF | Orthogonal RMS (px) | Max Residual (px) | $\chi^2$ | $\chi^2_\nu$ | $\text{AIC}_c$ | $\text{BIC}$ | Key Fitted Parameters |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **`S1` ($140^\circ$ Strict Rim, $N=29$)** | | | | | | | | | |
| `M4` Free Ellipse | 5 | 24 | **$0.1053$** | $0.1892$ | $17.16$ | $0.715$ | **$29.77$** | **$33.99$** | $a=18.31, b=13.70, b/a=0.748, \phi_{\text{min}}=39.1^\circ$ |
| `M3` Dorsal-Aligned Ellipse ($\phi_{\text{min}}=29.9^\circ$) | 4 | 25 | $0.1194$ | $0.2432$ | $22.42$ | $0.897$ | $32.08$ | $35.89$ | $a=19.72, b=16.24, b/a=0.823, \gamma=34.6^\circ$ |
| `M2` Bisector-Aligned Ellipse ($\phi_{\text{min}}=47.6^\circ$) | 4 | 25 | $0.1767$ | $0.3187$ | $48.08$ | $1.923$ | $57.75$ | $61.55$ | $a=18.23, b=13.86, b/a=0.760, \gamma=40.5^\circ$ |
| `M1` Circle ($b/a=1$) | 3 | 26 | $0.2193$ | $0.6157$ | $72.32$ | $2.782$ | $79.28$ | $82.42$ | $R=21.29\text{ px}$ |
| `M5` Parabolic Arch | 4 | 25 | $0.2956$ | $0.6927$ | $133.78$ | $5.351$ | $143.45$ | $147.25$ | $R_{\text{vert}}=17.28\text{ px}, \phi_{\text{axis}}=54.6^\circ$ |
| `M6b` Angular 3-Facet Polygon | 6 | 23 | $0.3991$ | $0.9445$ | $243.84$ | $10.602$ | $259.66$ | $264.05$ | 3 straight segments |
| `M6a` Angular 2-Facet Polygon | 4 | 25 | $0.8873$ | $2.3649$ | $1194.10$ | $47.764$ | $1203.76$ | $1207.57$ | 2 straight segments |
| **`S2` ($160^\circ$ Full Rim, $N=33$)** | | | | | | | | | |
| **`M3` Dorsal-Aligned Ellipse ($\phi_{\text{min}}=29.9^\circ$)** | **4** | **29** | **$0.1615$** | **$0.4403$** | **$35.53$** | **$1.225$** | **$44.96$** | **$49.52$** | $a=20.00, b=16.93, b/a=0.846, \gamma=32.2^\circ$ |
| `M4` Free Ellipse | 5 | 28 | $0.1682$ | $0.5002$ | $36.98$ | $1.321$ | $49.21$ | $54.47$ | $a=19.74, b=16.46, b/a=0.834, \phi_{\text{min}}=32.5^\circ$ |
| `M2` Bisector-Aligned Ellipse ($\phi_{\text{min}}=47.6^\circ$) | 4 | 29 | $0.2658$ | $1.0462$ | $100.50$ | $3.466$ | $109.93$ | $114.49$ | $a=19.17, b=15.95, b/a=0.832, \gamma=33.7^\circ$ |
| `M1` Circle ($b/a=1$) | 3 | 30 | $0.2685$ | $0.7099$ | $109.46$ | $3.649$ | $116.29$ | $119.95$ | $R=21.02\text{ px}$ |
| `M5` Parabolic Arch | 4 | 29 | $0.3697$ | $0.7882$ | $216.34$ | $7.460$ | $225.77$ | $230.33$ | $R_{\text{vert}}=16.17\text{ px}, \phi_{\text{axis}}=55.9^\circ$ |
| `M6b` Angular 3-Facet Polygon | 6 | 27 | $0.4426$ | $0.9740$ | $309.19$ | $11.451$ | $324.42$ | $330.17$ | 3 straight segments |
| `M6a` Angular 2-Facet Polygon | 4 | 29 | $1.1221$ | $2.7103$ | $1923.31$ | $66.321$ | $1932.74$ | $1937.30$ | 2 straight segments |
| **`S3` ($250^\circ$ Lobe-Excluded, $N=50$)** | | | | | | | | | |
| `M4` Free Ellipse | 5 | 45 | $0.8223$ | $4.3147$ | $832.20$ | $18.493$ | $843.57$ | $851.76$ | $a=20.31, b=15.30, b/a=0.754, \phi_{\text{min}}=37.0^\circ$ |
| **`S4` ($360^\circ$ Full Dark Patch, $N=72$)** | | | | | | | | | |
| `M4` Free Ellipse | 5 | 67 | **$1.7595$** | **$5.3562$** | **$5215.69$** | **$77.846$** | **$5226.60$** | **$5237.07$** | $a=19.64, b=17.44, b/a=0.888, \phi_{\text{min}}=40.0^\circ$ |

### 3.2 Failed Method Report: Full-Contour ($360^\circ$) Ellipse Fitting and Partial-Arc Degeneracy
Two critical methodological failures were identified and quantified during modeling:
1. **Failure of Full $360^\circ$ Dark-Patch Ellipse Fitting (`S4`)**:  
   Attempting to fit an ellipse to the entire $360^\circ$ dark patch (`S4`) fails catastrophically ($\text{RMS} = 1.760\text{ px}$, $\chi^2_\nu = 77.85$). **Cause**: As proven by 3D solar shadow ray casting (`figures/diag05_competing_3d_models.png`, Panel 3), the lower-right boundary (`Zone 4`, $\theta \in [-45^\circ, +145^\circ]$) is **not** the rim of the object; it is the cast shadow of the upper-left overhanging rim (`Zone 3`) projected along $\theta_{\text{shadow}} = +63.43^\circ$ across irregular regolith and a pebble at $(1083, 979)$.
2. **Partial-Arc Center–Aspect-Ratio Degeneracy on `S1`/`S2`**:  
   When fitting a 5-DOF ellipse strictly to the observable physical rim (`S1` $140^\circ$ or `S2` $160^\circ$), the unmeasured lower-right half allows the fitted center $(x_c, y_c)$ to trade off against the semi-axes $(a, b)$ (`figures/diag04_endface_models.png`, Panel 4). For example, on `S2`, varying $b/a$ from $0.75$ to $0.95$ along the dorsal axis orientation changes the orthogonal RMS residual only between $0.162\text{ px}$ and $0.285\text{ px}$ while shifting $(x_c, y_c)$ by $3.5\text{ px}$ into the shadow. Bootstrap resampling ($N=200$ iterations with $0.12\text{ px}$ noise) yields $b/a = 0.823 \pm 0.037$ ($95\%\text{ CI}: [0.730, 0.884]$, implied circular tilt $\gamma = 34.5^\circ \pm 3.8^\circ$) and $\phi_{\text{minor}} = 32.2^\circ \pm 6.4^\circ$ on `S2`.

### 3.3 Projective Proof Against an Uncovered Right Circular Cylinder (`step5_3d_interpretations.json`)
For a right circular cylinder of radius $R$ at distance $D$ whose axis $\hat{\mathbf{a}}$ is tilted by angle $\gamma$ relative to the camera line of sight, its two parallel 3D silhouette limbs intersect in the image plane at the vanishing point at distance $d_{\text{vp}} = f_{\text{local}} \tan\gamma$, producing a 2D limb convergence angle:
$$2\alpha_{\text{cyl}}(\gamma) = 2 \arctan\left(\frac{r_{\text{px}}}{f_{\text{local}} \tan\gamma}\right)$$
With $f_{\text{local}} = 13,458.3\text{ px/rad}$ and $r_{\text{px}} \approx 15\text{ px}$ (`figures/diag05_competing_3d_models.png`, Panel 1):
- For $\gamma = 30^\circ$ ($b/a = 0.866$), $d_{\text{vp}} = 7,770\text{ px}$ and **$2\alpha_{\text{cyl}} = 0.221^\circ$** (vs. observed **$35.348^\circ \pm 0.624^\circ$**).
- For $\gamma = 45^\circ$ ($b/a = 0.707$), $d_{\text{vp}} = 13,458\text{ px}$ and **$2\alpha_{\text{cyl}} = 0.128^\circ$**.
- To produce $2\alpha \approx 35.35^\circ$ by perspective foreshortening alone would require $\gamma \approx 0.19^\circ$ ($d_{\text{vp}} \approx 45\text{ px}$), which would force the circular end-face to have $b/a = \cos(0.19^\circ) = 0.999994$ and require the cylinder to have a 3D length-to-diameter ratio of $L_{3\text{D}}/(2R) \approx 436$ ($\sim 4.5\text{ m}$ long pointing within $0.2^\circ$ of the camera). Thus, **perspective foreshortening of an uncovered right circular cylinder cannot explain the $35.35^\circ$ convergence**.

### 3.4 Transverse Photometric Clinometry Across the Sunlit Body (`step5_3d_interpretations.json`)
Across $N=145$ interior radiance measurements along 5 transverse cross-sections perpendicular to the bisector ($u \in [15, 29]\text{ px}$ from the apex, $v/w_{1/2} \in [-0.72, +0.72]$; `figures/diag05_competing_3d_models.png`, Panel 2):
- A **flat planar facet model** ($I(v) = c_0 + c_1 v$, accounting for any linear dust/illumination gradient across a plane) yields $\text{RMS}_{\text{rel}} = 1.291\%$.
- A **convex curved surface model** ($I(v) = c_0 + c_1 v + c_2 v^2$) reveals a highly significant downward-concave second derivative $c_2 = -0.04112 \pm 0.00557$ (**$z = 7.38\sigma$**), reducing the residual to $\text{RMS}_{\text{rel}} = 1.098\%$ (identical to a Lambertian + ambient curved cross-section, $\text{RMS}_{\text{rel}} = 1.100\%$).
- Crucially, the transverse radiance peaks near the lower-left (ventral) margin ($v_{\text{peak}}/w_{1/2} = -0.89$) and rolls off smoothly toward the upper-right (dorsal) limb, showing that the dorsal boundary is a grazing convex limb while the ventral boundary truncates the surface near peak solar incidence.

---

## 4. Inferences: What the Measurements Support and How Strongly

To maintain strict scientific rigor, we explicitly separate three distinct levels of inference:

### 4.1 Geometric Consistency with Candidate Shapes
1. **Uncovered Right Circular Cylinder (Model H1a)**: **Geometrically Inconsistent (Rejected at $>50\sigma$)**. Parallel 3D limbs in a $5.6^\circ\text{ FOV}$ telephoto camera cannot converge at $35.35^\circ$ without extreme foreshortening ($\gamma = 0.19^\circ$) that contradicts both the finite length of the object and the elliptical curvature of the arch.
2. **Obliquely Buried Right Circular Cylinder (Model H1b)**: **Geometrically Consistent**. If a cylinder of diameter $2a \approx 39.5\text{ px}$ ($11.6\text{ mm}$) lies with its exposed upper limb along $\theta_{\text{dorsal}} = 29.88^\circ$ and is progressively overlapped on its lower-left flank by an oblique foreground regolith slope/ridge along $\theta_{\text{ventral}} = 65.23^\circ$, its circular end-face must have its minor axis at $\phi_{\text{minor}} = 29.88^\circ$. Remarkably, the unconstrained 5-DOF ellipse fit to the $160^\circ$ proximal arch (`S2`) independently yields $\phi_{\text{minor}} = 32.54^\circ \pm 6.37^\circ$ (a $2.67^\circ$ or $0.42\sigma$ match!), and the 4-DOF dorsal-aligned ellipse (`M3`) achieves the best information criterion score ($\text{AIC}_c = 44.96$, $\text{RMS} = 0.1615\text{ px}$) of any model tested on `S2`.
   - *Preserved Tension / Contradictory Evidence for H1b*: If a circular cylinder is intersected by a flat horizontal ground plane (grazing angle $23.95^\circ$), the 3D cylinder–plane intersection curve is an ellipse whose 2D projection has a transverse sagitta of $\sim 3\text{–}5\text{ px}$, whereas the observed ventral edge is nearly straight ($\text{RMS} = 0.562\text{ px}$). For H1b to hold, the occluding regolith cannot be a horizontal plane intersecting the cylinder; it must be a foreground soil crest/lip viewed nearly edge-on along the line of sight.
3. **Conical Frustum / Tapered Cone (Model H2)**: **Geometrically Consistent with Longitudinal Edges; Moderate Tension with End-Face Axis**. A right circular cone with 3D half-opening angle $\beta \approx 10^\circ\text{–}14^\circ$ tilted at $\gamma \approx 34^\circ\text{–}42^\circ$ naturally produces two straight silhouette limbs converging at $2\alpha = 35.35^\circ$.
   - *Preserved Tension / Contradictory Evidence for H2*: For a symmetric unburied right circular cone, the minor axis of the elliptical base must align with the limb bisector $\theta_{\text{bis}} = 47.55^\circ$. On the $160^\circ$ proximal arch (`S2`), forcing $\phi_{\text{minor}} = 47.55^\circ$ (`M2`) degrades the fit from $\text{RMS} = 0.162\text{ px}$ ($\text{AIC}_c = 44.96$) to $\text{RMS} = 0.266\text{ px}$ ($\text{AIC}_c = 109.93$, $\Delta\text{AIC}_c = +64.97$), unless the lower-left corner of the cone base is also slightly occluded by soil.
4. **Convex Tapered Sedimentary Clast / Ventifact Wedge with Undercut Overhang (Model H3b)**: **Fully Consistent**. A wind-abraded or conchoidally spalled siltstone/sandstone clast with a gently convex upper ridge ($z = 7.38\sigma$ convexity), a wedge-shaped planform ($35.35^\circ$), and a curvi-planar undercut lower-right face overhanging the soil matches all boundary, photometric, and shadow-casting constraints without requiring exact rotational symmetry.

### 4.2 Evidence Favoring Particular Shapes Over Alternatives
- **Smoothly Curved Rim + Convex Surface vs. Angular/Planar Rock Fragment**: **Very Strong Evidence ($\Delta\text{AIC}_c > 275$ on rim; $7.38\sigma$ on surface photometry)**. The object is definitively not a flat-topped angular broken rock plate; both its terminal arch and its transverse photometric profile exhibit smooth, continuous curvature.
- **Convex Ventifact / Tapered Spall (H3b) vs. Buried Cylinder (H1b) vs. Conical Body (H2)**: **Weak / Inconclusive Discrimination ($\Delta\text{RMS} < 0.1\text{ px}$)**. Because only the upper sunlit flank and a $140^\circ\text{–}160^\circ$ arc of the overhanging rim are visible—while the lower-right cavity/underhang is in deep shadow and the lower-left boundary contacts regolith—the available pixels cannot uniquely discriminate between a rotational solid (buried cylinder or cone) and a non-rotational curvi-planar geological clast (ventifact/spall).

### 4.3 Evidence About Physical Origin (Natural Geological vs. Artificial)
- **Physical Origin Cannot Be Established from Monocular Conic Fits**: Geometric consistency of a $160^\circ$ arch ($\sim 35\text{ px}$ across) with an ellipse ($\text{RMS} = 0.16\text{ px}$) and a $37\text{ px}$ dorsal edge with a straight line ($\text{RMS} = 0.26\text{ px}$) is a statement about **low-order smooth differential geometry over a $10\text{–}14\text{ mm}$ feature**, not proof of manufactured origin. Both manufactured cylindrical/conical hardware and natural aeolian ventifacts / spalled concretions / laminated siltstone fragments produce smooth arcs and straight edges over $\sim 40\text{ px}$ spans.

---

## 5. Robustness and Sensitivity Testing (`step6_robustness_and_sensitivity.py`)

Our conclusions were subjected to four independent perturbation batteries (`figures/diag06_robustness_sensitivity.png`):
1. **Boundary Trimming & Pebble Exclusion**: Trimming $15\%$ or $25\%$ of stations from both ends of the longitudinal edges, restricting to the upper or lower halves, or excising the ventral pebble contact zone ($y \in [978.5, 986.5]$) keeps the convergence angle within $33.9^\circ\text{ to }38.3^\circ$ (baseline $35.35^\circ$) and dorsal straightness within $0.19\text{–}0.26\text{ px}$.
2. **Subpixel Estimator & Interpolation Sensitivity**: Switching between parametric `erf` ODR fitting, non-parametric Gaussian parabolic gradient peaks, and integer-pixel centroids changes $\theta_{\text{dorsal}}$ by $\le 0.18^\circ$ ($29.88^\circ$ vs. $30.05^\circ$) and convergence $2\alpha$ by $\le 0.12^\circ$ ($35.35^\circ$ vs. $35.23^\circ$).
3. **Cross-Product & Spectral Band Invariance**: Across all four PDS RDR products (`DRXX` 16-bit raw, `DRCX` 8-bit color, `DRLX` 16-bit `CAHV` linearized, `DRCL` 8-bit linearized) and across individual Red, Green, and Blue spectral bands, $\theta_{\text{dorsal}}$ varies by only $0.19^\circ$ ($29.88^\circ\text{–}30.07^\circ$), $2\alpha$ varies within $33.89^\circ\text{–}35.35^\circ$, and the free-ellipse aspect ratio on `S2` remains within $b/a \in [0.821, 0.846]$.
4. **Monte Carlo Correlated Noise Injection**: Injecting spatially correlated ($\sigma_{\text{spatial}} = 0.8\text{ px}$) synthetic Bayer-demosaicing noise at $1\times$, $2\times$, and $3\times$ the empirical background noise ($\sigma_I = 7.78\times 10^{-3}\text{ W m}^{-2}\text{ sr}^{-1}\text{ nm}^{-1}$) yields $2\alpha = 34.0^\circ \pm 1.0^\circ$ ($1\times$) and $b/a = 0.843 \pm 0.041$ ($1\times$), confirming no noise-induced fitting bias.

---

## 6. Limitations: What Cannot Be Determined and Required Additional Data

From the single monocular image `3556MR1025170721700585C00`, the following properties are **strictly underdetermined**:
1. **Absolute Metric Scale ($\pm 10\%$ within focus range; $+31\%$ if on flat site plane)**: Without stereo disparity, slant distance $D$ is known only via the autofocus motor position (`3.957 m`, focus range $3.6\text{–}4.4\text{ m}$), leaving a $\sim \pm 10\%$ scale uncertainty on all millimeter dimensions.
2. **True 3D Cross-Section Closure and Interior Depth**: Because the lower-right half of the dark patch (`Zone 4`) is a solar cast shadow on the soil ($\theta_{\text{shadow}} = +63.43^\circ$) and the dark core ($I = 0.0136\text{ W m}^{-2}\text{ sr}^{-1}\text{ nm}^{-1}$, $\text{DN} = [180, 118, 58]$) reflects uniform ambient sky/ground-shine without resolvable internal walls, it is impossible to determine whether the overhanging arch encloses a hollow tubular cavity or simply overhangs flat regolith.
3. **Subsurface Continuation Along the Ventral Flank**: Whether the object terminates along $\theta_{\text{ventral}} = 65.23^\circ$ (cone/wedge) or continues beneath the regolith as a constant-diameter cylinder cannot be resolved from a single viewing azimuth.

**Additional Information Required to Discriminate Competing Models**:
- **Overlapping Stereo Pair (Mastcam-Left M-34 or Mastcam-100 Stereo)**: Would immediately fix the slant distance $D$ to $<1\%$ and provide 3D surface normals across the sunlit body and local regolith slope.
- **Second Viewing Azimuth or Low-Solar-Elevation Illumination**: Viewing from a different rover pose would reveal whether the ventral boundary is a foreground soil ridge occluding a cylinder, and lower sun angle would illuminate beneath the lower-right overhang to distinguish a hollow interior from a solid undercut rock face.

---

## 7. Conclusion

Based on reproducible subpixel measurements on the primary 16-bit lossless-compressed NASA PDS imagery (`3556MR1025170721700585C00_DRXX` and `_DRLX`) and exact `CAHVOR`/`CAHV` camera modeling, the Sol 3556 target is a **centimeter-scale object ($10.5\text{ mm}$ arch chord width by $14.1\text{ mm}$ exposed dorsal length at the $3.957\text{ m}$ best-focus distance) possessing a smoothly convex sunlit upper surface ($7.38\sigma$ transverse convexity), two straight longitudinal boundaries converging toward the upper-left at $35.35^\circ \pm 0.62^\circ$ ($\text{RMS} = 0.262\text{ px}$ dorsal, $0.589\text{ px}$ ventral), and a smooth $160^\circ\text{–}175^\circ$ overhanging terminal arch ($\text{RMS} = 0.162\text{ px}$) that casts a $+63.43^\circ$ solar shadow onto the Martian regolith**. An uncovered right circular cylinder is definitively excluded by projective geometry ($>50\sigma$), leaving three observationally degenerate 3D interpretations: (1) a convex, wedge-tapered sedimentary spall or aeolian ventifact with an undercut overhanging lip, (2) a physically tapered conical/frustum body, or (3) a right circular cylinder tilted at $\gamma \approx 32^\circ\text{–}35^\circ$ whose lower-left half is progressively buried beneath a foreground regolith ridge.

---

## 8. Targeted Correction: Single Upper-Right Pebble Outlier Exclusion & Rear Terminal Contour Reassessment (`step8_pebble_correction_and_rear_terminus.py`)

Following a targeted feature-association review of the adjacent upper-right pebble and the rear terminal contour (`figures/diag07_pebble_and_rear_terminus_zoom.png` and `figures/diag08_pebble_correction_and_rear_terminus.png`), we preserved all Phase 1 results for comparison and performed a focused reanalysis of (1) the front rim excluding only the single pebble-contaminated outlier and (2) the rear terminal contour along the true boundary between the darker blue background and the lighter greens/yellows of the object (`step8_pebble_and_rear_terminus.json`).

### 8.1 Identification & Exclusion of the Single Pebble-Contaminated Rim Outlier
1. **Front Opening Rim (`N = 36` across $\theta \in [+150^\circ, -35^\circ]$)**:
   - Across the 36 radial stations on the front rim, **35 points** trace the target's dark inner opening boundary cleanly (`theta` $\in [+150^\circ, -50^\circ] \cup [-40^\circ, -35^\circ]$).
   - **Only one single far outlying point** — at **$\theta = -45.0^\circ$** ($x_{\text{erf}} = 1083.34, y_{\text{erf}} = 969.16$, $r_{\text{erf}} = 22.40\text{ px}$) — jumps $+2.4\text{ px}$ outward across the narrow shadow gap onto the separate upper-right pebble ($x \in [1072, 1084], y \in [961, 970]$), whereas its immediate neighbors at $\theta = -50.0^\circ$ ($1080.51, 969.50$, $r = 19.86\text{ px}$) and $\theta = -40.0^\circ$ ($1083.09, 971.92$, $r = 20.34\text{ px}$) sit directly on the rim.
   - All 26 dorsal longitudinal stations ($\theta_{\text{dorsal}} = 29.878^\circ \pm 0.244^\circ$, $\text{RMS} = 0.2618\text{ px}$) and all 22 clean ventral stations ($\theta_{\text{ventral}} = 65.217^\circ \pm 0.674^\circ$, $\text{RMS} = 0.5624\text{ px}$) lie on the target body and are retained without over-exclusion.

### 8.2 Impact of Excluding the Single Pebble Outlier ($\theta = -45.0^\circ$) on Front-Face Models
Excluding **only the single outlying point at $\theta = -45.0^\circ$** ($N = 35$ clean rim points vs. $N = 36$ uncorrected rim points) reduces the orthogonal fit residual across the entire $175^\circ$ front rim by **more than $2.5\times$** (`figures/diag08_pebble_correction_and_rear_terminus.png`, Panel 2):

| Front-Rim Dataset & Model | $N$ | $k$ | Semi-Major $a$ (px) | Semi-Minor $b$ (px) | Aspect Ratio $b/a$ | Minor Axis $\phi_{\text{minor}}$ | Implied Circular Tilt | Orthogonal RMS (px) | Max Residual (px) | $\text{AIC}_c$ | $\text{BIC}$ |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Uncorrected 36-Pt Rim (`M4` Free Ellipse, incl. $\theta=-45^\circ$)** | 36 | 5 | $19.52$ | $16.00$ | $0.8194$ | $40.37^\circ$ | $34.97^\circ$ | $0.4167$ | $1.8712$ | $263.78$ | $269.70$ |
| **Uncorrected 36-Pt Rim (`M3` Dorsal-Aligned $29.88^\circ$)** | 36 | 4 | $20.33$ | $17.40$ | $0.8558$ | $29.88^\circ$ | $31.15^\circ$ | $0.4110$ | $2.0542$ | $257.65$ | $262.66$ |
| **Uncorrected 36-Pt Rim (`M2` Bisector-Aligned $47.92^\circ$)** | 36 | 4 | $18.92$ | $14.76$ | $0.7805$ | $47.92^\circ$ | $38.70^\circ$ | $0.4519$ | $1.7438$ | $302.18$ | $307.19$ |
| **Uncorrected 36-Pt Rim (`M1` Circle)** | 36 | 3 | $20.12$ | $20.12$ | $1.0000$ | — | $0.00^\circ$ | $0.5410$ | $1.4184$ | $392.42$ | $396.40$ |
| **Clean 35-Pt Rim (`M3` Dorsal-Aligned $29.88^\circ$, Excl. $\theta=-45^\circ$)** | **35** | **4** | **$19.95$** | **$16.74$** | **$0.8392$** | **$29.88^\circ$** | **$32.94^\circ$** | **$0.1618$** | **$0.5056$** | **$45.95$** | **$50.84$** |
| **Clean 35-Pt Rim (`M4` Free Ellipse, Excl. $\theta=-45^\circ$)** | **35** | **5** | **$19.72 \pm 0.39$** | **$16.42 \pm 0.60$** | **$0.8330 \pm 0.0178$** | **$32.70^\circ \pm 4.23^\circ$** | **$33.59^\circ$** | **$0.1639$** | **$0.5037$** | **$49.23$** | **$54.93$** |
| **Clean 35-Pt Rim (`M2` Bisector-Aligned $47.92^\circ$, Excl. $\theta=-45^\circ$)** | 35 | 4 | $18.60$ | $14.50$ | $0.7795$ | $47.92^\circ$ | $38.79^\circ$ | $0.2883$ | $1.2488$ | $128.73$ | $133.62$ |
| **Clean 35-Pt Rim (`M1` Circle, Excl. $\theta=-45^\circ$)** | 35 | 3 | $19.70$ | $19.70$ | $1.0000$ | — | $0.00^\circ$ | $0.4551$ | $1.0630$ | $292.18$ | $296.09$ |
| **Clean 35-Pt Rim (`M5` Parabolic Arch, Excl. $\theta=-45^\circ$)** | 35 | 4 | — | — | — | $68.64^\circ$ | — | $0.5931$ | $1.2641$ | $606.17$ | $611.06$ |
| **Clean 35-Pt Rim (`M6b` Angular 3-Facet Rim, Excl. $\theta=-45^\circ$)** | 35 | 6 | — | — | — | — | — | $0.6256$ | $1.3628$ | $674.91$ | $681.24$ |

- **Key Finding on the Clean Front Face**: Once the single pebble outlier at $\theta = -45.0^\circ$ is removed, the unconstrained 5-DOF Free Ellipse (`M4`) converges to $\phi_{\text{minor}} = 32.70^\circ \pm 4.23^\circ$ — within **$2.82^\circ$ ($0.67\sigma$)** of the dorsal longitudinal edge ($29.88^\circ$) — with $b/a = 0.8330 \pm 0.0178$ ($95\%\text{ CI }[0.7877, 0.8578]$) and $\text{RMS} = 0.1639\text{ px}$ (practically identical to the 33-point `S2` proximal rim $\theta \in [+150^\circ, -50^\circ]$, where $a = 19.74\text{ px}, b = 16.46\text{ px}, b/a = 0.8341, \phi_{\text{minor}} = 32.54^\circ, \text{RMS} = 0.1682\text{ px}$). The 4-DOF Dorsal-Constrained Ellipse (`M3`, $\phi_{\text{minor}} = 29.88^\circ, b/a = 0.8392, \text{RMS} = 0.1618\text{ px}$) is the **#1 best-fitting model by both $\text{AIC}_c$ ($45.95$) and $\text{BIC}$ ($50.84$)**, outperforming the Bisector-Constrained Ellipse (`M2`, $\text{RMS} = 0.2883\text{ px}, \Delta\text{AIC}_c = +82.78$) and Circle (`M1`, $\text{RMS} = 0.4551\text{ px}, \Delta\text{AIC}_c = +246.23$).

### 8.3 Rear Terminal Contour Reassessment and Direct 1:1 Curvature Match to the Front Face
Tracing the 36 subpixel boundary points along the true radiometric transition between the darker blue background ($I \le 0.080\text{ W m}^{-2}\text{ sr}^{-1}\text{ nm}^{-1}$) and the lighter greens/yellows of the object ($I \ge 0.088\text{ W m}^{-2}\text{ sr}^{-1}\text{ nm}^{-1}$) around the rear termination (`figures/diag08_pebble_correction_and_rear_terminus.png`, Panels 1, 3, & 4) resolves the geometry of the rear terminus once partial burial along the lower-left flank is accounted for:

1. **Why an Unburied Miniature-Cap Fit Fails vs. Accounting for Partial Regolith Burial**:
   - If all 36 extracted points ($\theta \in [-210^\circ, -35^\circ]$) are treated as an unburied miniature cap whose center is artificially constrained to lie inside the visible tip ($y_c \le 959$), a coaxial oblate ellipse fails ($\text{RMS} = 0.648\text{ px}$) and a 5-DOF free ellipse is forced into a tiny ($a = 7.38\text{ px}, b = 4.07\text{ px}$), sideways ($\phi_{\text{minor}} = +80.90^\circ$) contour ($\text{RMS} = 0.306\text{ px}$).
   - **Physical Cause**: The lower-left flank of the object is partially buried beneath the sloping foreground regolith contact line ($\theta_{\text{ventral}} = 65.2^\circ$). Consequently:
     - Points $i = 0\dots 7$ ($\theta \in [-210^\circ, -175^\circ]$, $y \in [950.5, 954.2]$) lie along the **foreground soil burial cut-off** where regolith overlaps the lower-left side of the rear cap.
     - Points $i = 8\dots 31$ ($N = 24$, $\theta \in [-170^\circ, -55^\circ]$, $x \in [1027.9, 1039.2]$, $y \in [945.4, 949.9]$) trace the **true exposed upper-left arc of the rear terminal cap**.
     - Points $i = 32\dots 35$ ($\theta \in [-50^\circ, -35^\circ]$, $x \in [1039.7, 1041.1]$) lie past the upper-right tangent of the rear cap along the **straight dorsal generator** ($\theta_{\text{dorsal}} = 29.88^\circ$).

2. **Direct 1:1 Curve Match Between the Exposed Rear Terminus Arc and the Clean Front Face**:
   - When the artificial center bound is removed so the rear cap center can sit at its natural coaxial position beneath the burial line ($(x_{c,\text{rear}}, y_{c,\text{rear}}) = (1036.16, 964.87)$ in `DRXX`, coaxial with the front-face center $(1069.52, 986.17)$ at bearing $32.56^\circ$ and projected center separation $L_{\text{proj}} = 39.58\text{ px}$), **an exact 1:1 unscaled translation of the clean front-face ellipse fits all 24 points of the exposed rear-terminus arc to $\text{RMS} = 0.1856\text{ px}$** (maximum residual $0.3206\text{ px}$):

| Rear Terminus Model on Exposed Rear Cap Arc ($N = 24$, $\theta \in [-170^\circ, -55^\circ]$, $x \in [1027.9, 1039.2]$) | Free Params ($k$) | Fitted Center $(x_c, y_c)$ (`DRXX`) | Semi-Major $a$ (px) | Semi-Minor $b$ (px) | Scale Ratio $s = a_{\text{rear}}/a_{\text{front}}$ | Minor Axis $\phi_{\text{minor}}$ | Orthogonal RMS (px) | Max Residual (px) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **1:1 Unscaled Copy of Clean Dorsal-Aligned Front Face ($b/a = 0.8392$)** | **2** ($x_c, y_c$ only) | **$(1036.16, 964.87)$** | **$19.95$ (fixed)** | **$16.74$ (fixed)** | **$1.000$ (fixed)** | **$29.88^\circ$ (fixed)** | **$0.1856$** | **$0.3206$** |
| **1:1 Unscaled Copy of Clean Free Front Face ($b/a = 0.8330$)** | **2** ($x_c, y_c$ only) | **$(1036.89, 964.45)$** | **$19.72$ (fixed)** | **$16.42$ (fixed)** | **$1.000$ (fixed)** | **$32.70^\circ$ (fixed)** | **$0.1825$** | **$0.3129$** |
| **Coaxial Scaled Dorsal-Aligned Front Face (free scale $s$)** | **3** ($x_c, y_c, s$) | $(1035.98, 963.66)$ | $18.65$ | $15.65$ | **$0.9350$** | $29.88^\circ$ (fixed) | **$0.1841$** | **$0.3168$** |
| **Coaxial Scaled Free Front Face (free scale $s$)** | **3** ($x_c, y_c, s$) | $(1036.32, 962.58)$ | $17.75$ | $14.78$ | **$0.9001$** | $32.70^\circ$ (fixed) | **$0.1802$** | **$0.3085$** |
| **Extended 26-Pt Exposed Rear Arc ($i = 7\dots 32$, $\theta \in [-175^\circ, -50^\circ]$) — 1:1 Copy** | **2** ($x_c, y_c$ only) | $(1036.31, 964.83)$ | $19.95$ (fixed) | $16.74$ (fixed) | $1.000$ (fixed) | $29.88^\circ$ (fixed) | $0.2415$ | $0.6620$ |

3. **Synthesis of Revised Findings**:
   - **Front Rim**: Excluding only the single pebble-contaminated point ($\theta = -45.0^\circ$) yields a clean 35-point circular-projection ellipse ($a = 19.72\text{–}19.95\text{ px}$, $b = 16.42\text{–}16.74\text{ px}$, $b/a = 0.833\text{–}0.839$, $\text{RMS} = 0.1618\text{–}0.1639\text{ px}$) whose minor axis ($32.70^\circ \pm 4.23^\circ$) aligns within $2.8^\circ$ of the straight dorsal barrel edge ($29.88^\circ \pm 0.24^\circ$).
   - **Rear Terminus**: Once the oblique regolith burial cut-off on the lower-left ($y \in [950.5, 954.2]$) is distinguished from the exposed rear cap ($x \in [1027.9, 1039.2]$), **the exposed rear-terminus arc matches an unscaled 1:1 copy of the front face to $0.183\text{–}0.186\text{ px}$ RMS** (with free coaxial scaling yielding $s = 0.935$, consistent with a constant-diameter cylinder with minor perspective foreshortening over its axial length).
   - **Plain-English Summary**: See [report_layman.md](file:///d:/projects/martian-cylinder/independent-reconstruction/report_layman.md) for a non-technical companion guide explaining these findings, methods, and implications.



