# Fluidized-Sediment Pipes and the Sol 3556 Cylinder Candidate

**A morphological comparator study and reproducible protocol for quantitative follow-up**  
**13 November 2026**  
**Research note prepared for the *Martian Cylinder* investigation**

> **Status:** Completed source-figure comparison; quantitative geological-control fits **not completed**. The publicly examined published figures do not expose the necessary three feature families, and original-resolution comparator pixels were not available in the local analysis environment. The included numerical code was verified on synthetic data only. No fabricated control RMS values or origin probabilities are reported.

## Abstract

Rubin et al. (2017) describe interpreted fluidized-sediment pipes in Gale Crater, including examples at Yellowknife Bay, Dingo Gap, and Marias Pass. Their observations establish that erosion-resistant, approximately cylindrical geological bodies occur in the same crater as the Sol 3556 target. The relevant comparison, however, is more demanding than the use of the word *cylinder*. The Sol 3556 paper reports three distinct visible physical-boundary families: a near curved rim, a far curved termination of the **same body**, and a longitudinal exterior edge, jointly fitted by a six-parameter equal-section, common-axis, exact-tangency model. Its 85 observations have a reported 0.3788-pixel RMS; a front/dorsal-derived frozen ellipse predicts 18 rear stations withheld from registration at 0.2084 pixels RMS.

The present screening inspects the original published views in Rubin et al., Figures 2–4. Six pictured geological comparators were classified by which of the three required boundary families are actually observable. **None of the published views supplies an independently identifiable pair of axial terminations and a connecting exterior generator for one body.** Instead, most show one annular cross-section; one Utah example shows a weathered column but not independently measurable end curves. Consequently the specific three-feature joint model is **not applicable to these views as published**, and no honest residual or held-out error can be assigned. This is a documented observational non-equivalence, **not** a demonstration that sediment fluidization cannot create a similarly shaped object. Original calibrated images, genuinely comparable viewing geometry, and an independently annotated boundary inventory would be needed for a numerical discrimination test.

## 1. Specific question

**Does the published sediment-pipe record supply an observed geological comparator that exhibits the same *joint image-space configuration* as the Sol 3556 object?**

The study does **not** ask whether natural processes can make round structures (they can), or whether an image-space cylindrical reconstruction uniquely identifies composition or manufacture (it does not).

### Target benchmark (from the supplied technical paper)

| Measurement | Sol 3556 reported result |
|:--|--:|
| Near-rim stations | 35 |
| Far-termination stations | 24 |
| Dorsal exterior stations | 26 |
| Strict model parameters | 6: near center (2), semi-axes (2), axial separation (1), common angle (1) |
| Exact tangent constraint | Yes; upper edge not independently offset |
| Strict model unweighted RMS | 0.3788 native image pixel |
| Rear frozen-shape, 6-anchor / 18-withheld prediction | 0.2084 pixel RMS |
| Guarded contiguous rear holds | 0.2429 pixel RMS |
| Guarded three-family model holds | 0.7233 pixel RMS |
| Strict projected diameter | 39.99 pixels; ~11.76 mm at assumed focus-distance scenario |

*Source:* Bogner, *Subpixel Geometric Reconstruction of a Cylindrical Candidate in Curiosity Mastcam-100 Imagery*, 13 November 2026, pp. 7–13. These are **author-reported** figures, not independently recomputed here. The paper describes projected 2D constraints, **not** stereo reconstruction or measured manufacturing tolerances.

The target's diameter-normalized values are 0.3788/39.99 = **0.00947 diameters** for the full joint fit, and 0.2084/39.99 = **0.00521 diameters** for the 18 withheld rear positions. Normalization supports comparison across scales only when sampling methods, point selection, image quality, and visible geometry are matched.

## 2. Sources and observational method

Primary comparator source: Rubin, D. M., et al. (2017), “Fluidized-sediment pipes in Gale crater, Mars, and possible Earth analogs,” *Geology* **45**, 7–10, doi:10.1130/G38339.1. Inspect the actual photographs in **Figure 2B** (Yellowknife Bay), **Figure 3B** (Tappers), **Figure 3E** (western Dingo Gap), **Figure 3F** (Hewolf pair), and **Figures 4A–B** (Utah analogues). The cited paper's Table 1 identifies the relevant rover sols and abbreviated products.

Supplementary geological context: Brož et al. (2023), “An overview of sedimentary volcanism on Mars,” *Earth Surface Dynamics* **11**, 633–, section 6.1, doi:10.5194/esurf-11-633-2023. This independent review describes Gale pipe examples as circular, centimetres-high erosion-resistant rings associated with cementation, concentric layering, dikes, or deformation.

Each pictured example was evaluated against three **pre-specified image observables**:

- **N**: an identifiable curved physical boundary at one axial end of the same body (not a shadow contour).
- **R**: a separate curved physical boundary at its *other* axial end, separated along the body's longitudinal direction (not the cross-section of a second neighboring pipe).
- **D**: a connecting exterior material boundary suitable for a tangency-constrained longitudinal fit (not a bedding contact, soil boundary, or unrelated bright ridge).

The strict comparison is **eligible only when N + R + D are each independently observed** in one common registered image coordinate system. If a contour is hidden, does not correspond to a material edge, or could belong to another object, mark it *unavailable* or *ambiguous*. **Do not treat absence of an observable as a failed fit.**

### Findings matrix

| Published example | Diameter / scale reported | What the figure shows | N | R | D | Full three-feature joint comparison |
|:--|:--|:--|:--:|:--:|:--:|:--|
| Yellowknife Bay, Fig. 2B; sol 173 | ~7 cm in text; 10 cm in Table 1 | Raised concentric/irregular **one-section rim** in bedding, with ~2–3 cm relief | partial | no | ambiguous | **Not testable from this view** |
| Dingo Gap “Tappers,” Fig. 3B; sol 528 | 60–70 cm | Irregular raised ring with shallow bowl-shaped center | partial | no | no | **Not testable from this view** |
| 150 m west of Dingo Gap, Fig. 3E; sol 542 | ~20 cm | Circular exposure with internal concentric/eccentric layering | partial | no | no | **Not testable from this view** |
| Marias Pass “Hewolf,” Fig. 3F; sol 1051 | **Two objects:** 7 cm and 36 cm | Two separate circular structures, not two ends of one cylinder | partial | no | no | **Not testable from this view** |
| Utah Carmel/Page, Fig. 4A | Scale bar shown; no comparable calibrated diameter stated | Partly eroded upright **column** with irregular cemented rim | top visible | no demonstrable second end | sides visible | **Partial analogue; not full testable configuration** |
| Utah Carmel/Page, Fig. 4B | 10 cm scale bar | One annular **horizontal section** with eccentric and crinkly bands | partial | no | no | **Not testable from this view** |

Here “partial” means one cross-sectional boundary is visible, **not** that the target's near-rim extraction method has been reproduced. A single photographed ring can be quite circular without providing evidence about an axially separate terminal curve. The count **0 of 6 depicted comparator views eligible** is a statement about *photographic observability in a purposively selected sample*, not the frequency of cylinders in nature. Likewise, no 0/6 statistical inference is warranted.

![Schematic of the three-feature requirement and of geological views that expose only one section](assets/pipe-geometry-schematic.png)

*Figure 1. Original explanatory schematic, **not** a reconstruction or tracing of Rubin et al. imagery. Left: a viewing geometry in which both terminal curves and a connecting material edge can be measured. Center: a single annular section. Right: an eroded column with one end hidden.*

### Why the distinctions matter

1. **Cross-section versus paired ends.** The Rubin Mars photographs predominantly look down onto a preserved cross-section of a former subvertical pipe. A single ring may prove a circular local section; it cannot establish or contradict equal *two-ended* sections along the pipe axis.
2. **Two rings are not two ends.** The Marias Pass Hewolf image contains separate geological objects. Taking their curved rims as a “front” and “rear” pair would manufacture the target's longitudinal relationship out of unrelated features.
3. **An exposed column remains a natural possibility.** The Utah example is an important counter to any claim that natural sedimentary pipes cannot erode into isolated, approximately cylindrical masses. Its irregular exterior and limited end visibility mean that the present published photograph does not permit the target's paired-termination test. **It does not prove that such a fit is impossible** on another exposure.
4. **Different imaging geometries matter.** An overhead view of an annular pipe and an oblique view of a small horizontally exposed object do not expose the same physical boundaries. Comparing their simple ellipse RMS values would create a misleading common scale of “regularity.”

## 3. Scale and potential image-resolution limits

At a working target diameter of **1.176 cm**, Rubin's minimum 7 cm example is ~**6.0×** larger and its maximum 70 cm example ~**59.5×** larger. Differences in physical size by themselves provide no origin discrimination: geological forms occur across scales and the target distance is conditional.

Rubin et al. report approximately **0.23 mm per pixel** for the Yellowknife Bay Mastcam M100 image (Figure 2B). If the described 7 cm diameter is used, its apparent cross-section would span roughly **304 native pixels**; using the 10 cm Table 1 entry gives ~435 pixels. Thus the published geological target is *not intrinsically too small to measure*. A native calibrated image could support **single-rim boundary metrology**. However, multiplying pixels cannot reveal a second axial termination that is physically concealed by bedding or absent from the photographed view.

The target technical paper itself states that the visible partial terminal arcs do not uniquely determine its hidden 3D end faces. The same evidentiary restriction must apply to controls.

## 4. Quantitative audit attempted and what was actually run

A portable Python audit program and source inventory accompany this note:

- `pipe-comparison-audit.py`: ingests user-audited original-pixel point CSVs (`x,y`) for rim/near, rear, and dorsal families; computes a single-ellipse fit if only a ring is available; otherwise fits an unweighted **six-parameter common-section, common-axis, exact-tangent** image-space model and guarded contiguous coordinate holdouts. The fitting and holdout operations are executable, not placeholder pseudocode.
- `pipe-comparison-manifest.json`: records the seven cases (target plus six published controls), source figures, morphology notes, and missing point files. In the actual audit output each is explicitly **not testable from supplied station data**, with **no invented fit or error**.
- `pipe-comparison-results.json`: machine-readable record of the attempted run.
- `pipe-comparison-demo/`: **synthetic-only quality assurance** of the software. A generated constant-section body with 35 near, 24 rear, and 26 dorsal points plus 0.15-pixel Gaussian coordinate perturbations gave **0.149 px** joint RMS and **0.178 px** five-fold guarded RMS. **These are not geological control results** and must not be used in an origin comparison.

**Image acquisition blocker:** the current computational environment could read the publication and the user's technical paper but could not download the original radiometric arrays for the cited geological control views. It would be incorrect to claim that the 85-point pipeline was quantitatively applied to those raw images. Equally, the published figure views lack the full observable N+R+D geometry needed even if their pixel arrays were available.

**Algorithm compatibility caveat:** the included cross-control program uses unweighted least squares on native image-coordinate point sets; the author's strict M1 fit uses its recorded per-station uncertainty weights for parameter optimization and reports a separate unweighted RMS. Thus a control fitted by the supplied script must **not** be presented as a formally identical reimplementation of the target's original weighted pipeline. For a definitive matched study, both target and controls must run through one frozen algorithm with identical parameterization, selection rules, and data-processing conventions.

## 5. Protocol for a completed original-resolution test

1. **Acquire and verify source pixels.** Obtain the uncompressed/calibrated NASA Mastcam or Navcam PDS images for **sols 173, 528, 542, and 1051**, plus original source images of the terrestrial exposures. Use Rubin's abbreviated image identifiers **MR00926**, **MR002083**, **navcam00354**, and **ML004625** as *search keys*, not complete PDS product filenames. Preserve PDS labels, camera geometry, radiometric provenance, and SHA-256 checksums. Some views use Mastcam-left or Navcam and cannot be assumed to share Mastcam-right resolution or calibration.
2. **Choose physical boundaries before fitting.** Use a consistent, predeclared observation protocol. Have at least one independent annotator locate material/soil/shadow boundaries without seeing the candidate origin label or desired residual. Save candidate pixels, orientation, contrast polarity, uncertainty, and why any station is rejected.
3. **Screen eligibility.** A circular cross-section alone may be fitted as a single rim, but it is **ineligible** for the paired-termination test. Only an image with observed N+R+D should enter a joint-fit comparison; do not invent hidden ends or treat two objects as one.
4. **Normalize resolution and aperture.** Repeat all eligible comparisons using both native pixels and matched effective point-spread-function / downsampled resolution; record denominator as a visible model diameter, not physical millimeters inferred from uncertain range. Report both pixel RMS and RMS/diameter.
5. **Freeze the test.** Once feature definitions are complete, fit an equal-section constrained model; keep section size and orientation fixed for translated-rear tests. Include six-anchor and guarded held-out prediction when sufficient rear stations are visible. Avoid choosing test samples after inspecting error profiles.
6. **Model a genuine geological alternative.** Where a pipe is not exposed axially, quantify its visible rim roughness and layering, sedimentary contacts, and orientation instead of forcing an inapplicable cylinder model. A physical forward model of eroded/cemented sediment-pipe segments, imaged at the target's viewing angle, would supply a more direct natural comparator.
7. **State what is learned without converting absence to impossibility.** A failure of an eligible natural example to match the frozen geometry would reject that **specific photographic analogue** at the measured resolution. It would not reject sediment fluidization as an entire class of mechanisms. Likewise, failure to find an eligible comparator in a published figure set is not a statistical rejection.

**Acceptance decision for this round:** *No demonstrated quantitative geological match found; no direct numeric comparator fit executed; fluidized-sediment-pipe origin not excluded.*

## 6. Conclusions

The reviewer's invocation of Rubin et al. (2017) establishes a **relevant physical formation class** in Gale Crater, but it does not supply the particular measured counterexample asserted. The published examples largely depict single eroded annular cross-sections rather than an obliquely exposed finite cylinder with two observable terminal arcs linked by one longitudinal edge. This distinction is directly visible in the cited paper and can be evaluated without conjecture about ancient manufacturing.

The strongest supported conclusion is narrow and valuable: **none of the six inspected publication views is a ready-made image-space analogue for the target's three-family, frozen-geometry prediction test.** That is why “sedimentary pipes exist in Gale Crater” does not settle the Sol 3556 geometry. It is equally why the present review cannot claim to have proven that those pipes are physically incapable of producing it.

This matters for how the argument is framed. The unanswered question is quantitative: **can a documented natural sedimentary pipe, under a matched viewing and erosion scenario, reproduce the target's joint geometric relations and predictive holdout performance?** The published photographs and current study have not yet answered it.

### Insertable paragraph for the technical paper

> Rubin et al. (2017) document fluidized-sediment pipes in Gale Crater and provide an appropriate geological process analogue. Inspection of their illustrated Yellowknife Bay, Dingo Gap, and Marias Pass examples, and the terrestrial analogues in their Figure 4, shows that the published views predominantly expose annular sections or eroded columns rather than two axially separated terminal arcs joined by a single observable longitudinal material boundary. Consequently those figures do not provide the three measured feature families needed for a like-for-like reproduction of the present joint-cylinder fit or held-out rear prediction. This is an observational non-equivalence, not an exclusion of sediment-fluidization processes. A matched test would require source-resolution imagery of an exposed finite pipe segment and independently classified material boundaries.

## References and source locations

1. **Bogner, J.** (2026), *Subpixel Geometric Reconstruction of a Cylindrical Candidate in Curiosity Mastcam-100 Imagery*, technical manuscript, 13 November 2026, **pp. 6–13, 16**. Supplied PDF `martian-cylinder-technical-paper(2).pdf`; [GitHub research repository](https://github.com/CambrianMinds/martian-cylinder).
2. **Rubin, D. M., et al.** (2017), “Fluidized-sediment pipes in Gale crater, Mars, and possible Earth analogs,” *Geology* **45** (1), 7–10. **Figures 2B, 3B, 3E, 3F, 4A, 4B; Table 1.** [doi:10.1130/G38339.1](https://doi.org/10.1130/G38339.1). [Full PDF from the Schieber research lab](https://schiebershalemudstoneresearchlab.org/PDF/Rubin-et-al-2017-Geology-sediment-pipes.pdf).
3. **Brož, P., et al.** (2023), “An overview of sedimentary volcanism on Mars,” *Earth Surface Dynamics* **11**, section 6.1. [doi:10.5194/esurf-11-633-2023](https://doi.org/10.5194/esurf-11-633-2023).
4. **Bell, J. F., III, et al.** (2017), “The Mars Science Laboratory Curiosity rover Mastcam instruments: Preflight and in-flight calibration, validation, and data archiving,” *Earth and Space Science*. [doi:10.1002/2016EA000219](https://doi.org/10.1002/2016EA000219).
5. **NASA PDS**: [MSL Analyst's Notebook](https://an.rsl.wustl.edu/msl/) and [MSL Mastcam archive](https://pds-imaging.jpl.nasa.gov/data/msl/); source image selection must use verified complete identifiers.

**Research integrity note:** This document distinguishes (i) primary published observations, (ii) author-reported target fits, (iii) this review's morphological screening, and (iv) future or software-only tests. It does not imply independent remeasurement of another team's calibrated camera pixels.
