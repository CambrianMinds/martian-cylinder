# Sediment-pipe morphology comparison: research package

13 November 2026

This is a **screening report and reproducible audit scaffold**, not a completed numerical comparison against calibrated geological-control images. The report reviews actual published figures but does **not** claim to have fitted the 85-point model to the Mars or terrestrial analogue photographs.

## Files

- `sediment-pipe-morphology-comparison-2026-11-13.pdf`: illustrated, typeset seven-page comparative report.
- `sediment-pipe-morphology-comparison-2026-11-13.md`: editable Markdown source.
- `assets/pipe-geometry-schematic.png`: original explanatory schematic, *not* image-derived evidence.
- `pipe-comparison-audit.py`: constrained ellipse/axis/tangency fitting and guarded holdout implementation (unweighted).
- `pipe-comparison-manifest.json`: inventory of the target and six published comparator views, with all unavailable measurements explicitly declared.
- `pipe-comparison-results.json`: recorded source-inventory execution; no unmeasured control residuals.
- `pipe-comparison-demo/`: synthetic coordinate-data test, including its manifest, 35+24+26 point CSV files, and synthetic QA results. **Not geological evidence.**

## Run the available verification

You need Python 3.10+ and the libraries NumPy and SciPy:

```sh
python -m pip install numpy scipy
python pipe-comparison-audit.py --manifest pipe-comparison-manifest.json --out pipe-comparison-results.json
python pipe-comparison-audit.py --manifest pipe-comparison-demo/demo-manifest.json --out pipe-comparison-demo/demo-results.json
```

The first run should report all seven cases as `not_testable_from_supplied_station_data`. This is intentional. The demo should complete a numerical fit, but it operates on synthetically generated coordinates and must not be cited as a Mars comparison.

## Adding a real geological comparator

1. Retrieve the original calibrated image and label; record exact product name, sol, instrument, physical feature, source URL, and SHA-256.
2. Independently classify three sets of **physical material boundaries**, if actually visible: `near` terminal curve, `rear` terminal curve of the same body, and `dorsal` exterior line. Use native pixel coordinates, and never invent a hidden endpoint.
3. Save each family as a CSV with header `x,y`. For a geological section with only one ring, you may label one CSV as `rim` instead, but the output will only provide a single-ellipse fit. It will not generate a two-ended comparison.
4. In `pipe-comparison-manifest.json`, set the case's `boundary_files` to an object such as `{"near":"station_csv/pipe_near.csv","rear":"station_csv/pipe_rear.csv","dorsal":"station_csv/pipe_dorsal.csv"}`. A single rim case would use `{"rim":"station_csv/pipe_rim.csv"}`.
5. Re-run and inspect the per-family RMS, diameter-normalized RMS, and guarded folds. Review images and annotation quality before drawing inferences.

## Important qualification

The independent target paper's strict fit uses per-station uncertainty weights during optimization and reports a separate unweighted RMS. This script is an **unweighted** comparison implementation, so its output is not automatically identical to that paper's pipeline. A definitive cross-population comparison must rerun all images with the same frozen methodology, including weights, preselected segmentation, point spacing, resolution and optical-error modeling.

Source: Rubin et al. (2017), *Geology* 45, 7–10, [doi:10.1130/G38339.1](https://doi.org/10.1130/G38339.1), Figures 2–4 and Table 1. The full report provides all other source links.
