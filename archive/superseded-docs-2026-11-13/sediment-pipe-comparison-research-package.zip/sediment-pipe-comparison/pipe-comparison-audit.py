#!/usr/bin/env python3
"""Reproducible image-coordinate geometry comparison for sediment-pipe controls.

Requires manually audited physical-boundary point CSVs from original-resolution images.
This program DOES NOT find material boundaries automatically or infer missing endpoints.

Usage:
  python pipe-comparison-audit.py --manifest cases.json --out results.json
CSV columns: x,y (original native-image pixels, consistent within case).
"""
import argparse, csv, json, math
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares


def points(path):
    with open(path, newline='', encoding='utf8') as f:
        reader = csv.DictReader(f)
        if not {'x','y'} <= set(reader.fieldnames or []):
            raise ValueError(f'{path}: CSV requires x,y column names')
        a=np.array([[float(row['x']),float(row['y'])] for row in reader],float)
    if a.ndim!=2 or a.shape[1]!=2 or len(a)<4 or not np.isfinite(a).all():
        raise ValueError(f'{path}: invalid point array')
    return a


def coord(q,c,theta):
    u=np.array([np.cos(theta),np.sin(theta)])
    v=np.array([-np.sin(theta),np.cos(theta)])
    d=q-c
    return d@u,d@v


def ellipse_distance(q,c,a,b,theta):
    """Signed radial-near orthogonal residual; Newton projection to ellipse.

    a: semi-major in transverse v direction, b: semi-minor in axial u direction.
    For on-contour observations this is accurate; far-away points require a robust
    global nearest-point algorithm rather than Newton initialization.
    """
    x,y=coord(q,c,theta)
    t=np.arctan2(y/max(a,1e-6),x/max(b,1e-6))
    for _ in range(16):
        ct,st=np.cos(t),np.sin(t)
        xp,yp=b*ct,a*st
        dx,dy=-b*st,a*ct
        ddx,ddy=-b*ct,-a*st
        f=(xp-x)*dx+(yp-y)*dy
        df=dx*dx+dy*dy+(xp-x)*ddx+(yp-y)*ddy
        t=t-np.clip(f/(df+1e-12),-0.4,0.4)
    ct,st=np.cos(t),np.sin(t)
    # preserve signed residual to help optimization, approximate outward sign
    dist=np.sqrt((x-b*ct)**2+(y-a*st)**2)
    outward=(x*x/(b*b)+y*y/(a*a)-1.0)>=0
    return dist*np.where(outward,1,-1)


def rms(r): return float(np.sqrt(np.mean(np.asarray(r)**2))) if len(r) else None


def fit_single_rim(p):
    xymin=p.min(axis=0); xymax=p.max(axis=0)
    center=(xymin+xymax)/2
    s=np.maximum((xymax-xymin)/2,1.0)
    init=np.array([*center,max(s),min(s),0.0])
    def fun(z):return ellipse_distance(p,np.array(z[:2]),z[2],z[3],z[4])
    lo=[-np.inf,-np.inf,0.1,0.1,-np.pi]
    hi=[np.inf,np.inf,np.inf,np.inf,np.pi]
    sol=least_squares(fun,init,bounds=(lo,hi),max_nfev=400)
    x,y,a,b,th=sol.x
    return {'n':len(p),'rms_image_px':rms(fun(sol.x)), 'rms_over_diameter':rms(fun(sol.x))/(2*a),
            'params':{'center': [float(x),float(y)],'a':float(a),'b':float(b),'theta_rad':float(th)},
            'fit_success':bool(sol.success), 'warning':'Single ellipse: not a common-section or shared-axis test.'}


def residuals(p, families):
    xf,yf,a,b,L,t=p
    front,rear,dorsal=families
    center=np.array([xf,yf]);u=np.array([np.cos(t),np.sin(t)])
    rf=ellipse_distance(front,center,a,b,t)
    rr=ellipse_distance(rear,center-L*u,a,b,t)
    _,vd=coord(dorsal,center,t)
    rd=vd+a    # exact image-plane upper tangent, same as target definition
    return rf,rr,rd


def fit_joint(families, starting=None):
    front,rear,dorsal=families
    if min(map(len,families)) < 5: raise ValueError('Each family needs at least 5 samples')
    center=front.mean(axis=0)
    d=front.mean(axis=0)-rear.mean(axis=0)
    theta=math.atan2(d[1],d[0]); L=max(np.linalg.norm(d),1.)
    diameter=np.linalg.norm(front.max(axis=0)-front.min(axis=0))
    a=max(1.,diameter*.45);b=max(0.6,a*.82)
    z0=starting if starting is not None else np.array([center[0],center[1],a,b,L,theta])
    def fun(z):return np.hstack(residuals(z,families))
    lo=[-np.inf,-np.inf,0.05,0.05,0.05,-4*math.pi]
    hi=[np.inf,np.inf,np.inf,np.inf,np.inf,4*math.pi]
    fit=least_squares(fun,z0,bounds=(lo,hi),max_nfev=1800,
                      x_scale='jac',loss='linear')
    rs=residuals(fit.x,families)
    return fit,{'n_total':sum(map(len,families)),
                'rms_image_px':rms(np.hstack(rs)),
                'rms_over_diameter':rms(np.hstack(rs))/(2*fit.x[2]),
                'by_family_rms_px':{'near':rms(rs[0]),'rear':rms(rs[1]),'dorsal':rms(rs[2])},
                'parameters':dict(zip(['xf','yf','a','b','L','theta_rad'],[float(v) for v in fit.x])),
                'fit_success':bool(fit.success),'unweighted':True}


def guarded_cross_validation(families,k=5,guard=2):
    """For each of k folds, withhold one contiguous block in each family and guard neighbors."""
    all_err=[]; total=0
    for fold in range(k):
        train=[];test=[]
        for fam in families:
            ids=np.arange(len(fam))
            blocks=np.array_split(ids,k)
            block=blocks[fold]
            start,end=block[0],block[-1]
            drop=(ids>=max(0,start-guard))&(ids<=min(len(fam)-1,end+guard))
            train.append(fam[~drop]);test.append(fam[block])
        if min(map(len,train))<5:return {'status':'insufficient_train_samples'}
        fit,_=fit_joint(train)
        vals=residuals(fit.x,test)
        all_err.extend([*vals[0],*vals[1],*vals[2]])
        total+=sum(map(len,test))
    return {'status':'ok','n_tested':total,'rms_image_px':rms(all_err),
            'notes':'Retrospective coordinate-level blocked holdout; NOT independent boundary selection.'}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--manifest',required=True);ap.add_argument('--out',required=True)
    a=ap.parse_args(); mpath=Path(a.manifest).resolve(); data=json.loads(mpath.read_text(encoding='utf8'))
    results={'protocol':'paired-termination-and-tangent-v1','cases':{},
             'critical_notice':'Never infer an unobserved far termination or assign a residual to missing geometry.'}
    for case in data['cases']:
        name=case['id']; declared=case.get('boundary_files',{})
        found={}
        for k,v in declared.items():
            if v:
                file=mpath.parent/v
                if file.is_file():found[k]=points(file)
        out={'label':case['label'],'source':case.get('source'),'provided_families':list(found),
             'morphology_observation':case.get('observed_morphology',''),
             'limitations':case.get('limitations','')}
        if all(k in found for k in ['near','rear','dorsal']):
            families=[found['near'],found['rear'],found['dorsal']]
            _,res=fit_joint(families)
            out.update({'testability':'joint_test_completed','joint':res,
                        'guarded':guarded_cross_validation(families)})
        elif 'rim' in found and len(found['rim'])>=8:
            out.update({'testability':'single_rim_only','rim':fit_single_rim(found['rim']),
                        'not_performed':'Paired-terminal and dorsal joint test'})
        else:
            out.update({'testability':'not_testable_from_supplied_station_data',
                        'not_performed':'No control-image point measurements provided; no RMS assigned'})
        results['cases'][name]=out
    Path(a.out).write_text(json.dumps(results,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print('Cases:',len(results['cases']))
    for k,v in results['cases'].items():
        print(f"{k}: {v['testability']}",v.get('joint',{}).get('rms_image_px',''))

if __name__=='__main__': main()
